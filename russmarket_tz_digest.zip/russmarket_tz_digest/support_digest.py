#!/usr/bin/env python3
"""Deterministic rule layer for the daily support digest.

Pipeline
--------
1. An LLM extractor reads CRM records + chat export and returns JSON in the
   schema below (prompt: see solution.md, section 01).
2. This script applies the checks that must not depend on a model: deadlines,
   confirmation state, contradictions between CRM and chats.
3. The script prints a Markdown digest for the support team.

Input schema
------------
{
  "generated_at": "2026-10-19T10:00",
  "cases": [
    {
      "id": "C-17",
      "type": "onboarding" | "offboarding" | "delivery",
      "crm": {
        "deadline": "2026-10-20",  (date only = whole day)
        "status": "Documents expected",
        "documents_received": false,
        "approval": {"by": "...", "at": "..."} | null,
        "confirmation": {"by": "...", "at": "..."} | null
      },
      "chat": {
        "claims": {
          "documents_sent": true,
          "channel": "manager DM",
          "approval_mentioned": true,
          "eta_not_before": "13:00",
          "accepted_mentioned": true,
          "quantity_checked": true
        },
        "quotes": [{"role": "employee", "text": "..."}]
      }
    }
  ]
}

Usage
-----
    python3 support_digest.py digest_input.json [--now 2026-10-19T10:00]

The script has no dependencies outside the standard library.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

PRIORITY_RANK = {"P1": 0, "P2": 1, "P3": 2, "P4": 3}
PRIORITY_LABEL = {
    "P1": "P1 — срочно",
    "P2": "P2 — сегодня",
    "P3": "P3 — плановый контроль",
    "P4": "P4 — закрыто",
}
TYPE_LABEL = {
    "onboarding": "Оформление сотрудника",
    "offboarding": "Увольнение сотрудника",
    "delivery": "Поставка карт",
}


def parse_dt(value):
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value))
    except ValueError:
        return None


def clock(dt: datetime) -> str:
    """HH:MM, or an empty string when the time is exactly midnight."""
    if dt.hour == 0 and dt.minute == 0:
        return ""
    return f", {dt:%H:%M}"


def deadline_state(deadline: datetime | None, now: datetime) -> tuple[str, str]:
    """Return (state, human label) for a deadline."""
    if deadline is None:
        return "unknown", "срок не указан"
    date_only = deadline.hour == 0 and deadline.minute == 0
    if date_only:
        # CRM gave only a day ("завтра", "сегодня"): the deadline is the whole day.
        days = (deadline.date() - now.date()).days
        if days < 0:
            return "overdue", f"просрочен ({deadline:%d.%m})"
        if days == 0:
            return "today", "сегодня"
        if days == 1:
            return "tomorrow", "завтра"
        return "future", deadline.strftime("%d.%m.%Y")
    delta = deadline - now
    if delta.total_seconds() < 0:
        hours = int(abs(delta.total_seconds()) // 3600)
        label = "просрочен" if hours == 0 else f"просрочен на {hours} ч"
        return "overdue", label
    if deadline.date() == now.date():
        return "today", f"сегодня{clock(deadline)}"
    if (deadline.date() - now.date()).days == 1:
        return "tomorrow", f"завтра{clock(deadline)}"
    return "future", deadline.strftime("%d.%m.%Y") + clock(deadline)


def evaluate(case: dict, now: datetime) -> dict:
    case_type = case.get("type", "unknown")
    crm = case.get("crm") or {}
    chat = case.get("chat") or {}
    claims = chat.get("claims") or {}

    deadline = parse_dt(crm.get("deadline"))
    dstate, dlabel = deadline_state(deadline, now)

    confirmed: list[str] = []
    corroborated: list[str] = []
    chat_only: list[str] = []
    missing: list[str] = []
    conflicts: list[str] = []

    priority = "P3"
    action = "Проверить данные в CRM и закрыть карточку."
    check = "Тип операции и полноту данных в CRM."
    start = "Открыть карточку и сверить статус в CRM."

    if case_type == "onboarding":
        docs_in_crm = bool(crm.get("documents_received"))
        if docs_in_crm:
            confirmed.append("Документы приняты и заведены в CRM")
        else:
            missing.append("Документы не приняты в CRM")
        if claims.get("documents_sent") and not docs_in_crm:
            channel = claims.get("channel") or "личную переписку"
            chat_only.append(f"Сотрудник сообщил, что отправил документы ({channel})")
            conflicts.append("Переписка не заменяет приёмку документов в CRM")

        if dstate in ("today", "tomorrow") and not docs_in_crm:
            priority = "P1"
            action = (
                "Получить документы у руководителя, завести их в CRM и проверить "
                "комплектность до первого рабочего дня."
            )
            check = (
                "Получены ли документы руководителем, полный ли комплект и "
                "совпадает ли дата выхода в CRM с фактической."
            )
            start = (
                "Написать руководителю сотрудника и подтвердить, что документы "
                "получены; затем проверить статус оформления в CRM."
            )
        elif not docs_in_crm:
            priority = "P2"
            action = "Запросить документы и завести их в CRM."
            start = "Связаться с сотрудником или руководителем и запросить документы."
        else:
            priority = "P3"

    elif case_type == "offboarding":
        approval = crm.get("approval")
        approval_ok = bool(approval)
        if approval_ok:
            by = approval.get("by") or "руководитель"
            confirmed.append(f"Подтверждение руководителя в CRM ({by})")
        else:
            missing.append("Подтверждение ответственного руководителя отсутствует в CRM")
        if claims.get("approval_mentioned") and not approval_ok:
            chat_only.append("«С руководителем всё обсудили» — со слов сотрудника")
            conflicts.append("Устное согласие сотрудника не является подтверждением руководителя")

        if dstate in ("today", "overdue") and not approval_ok:
            priority = "P1"
            action = (
                "Получить письменное подтверждение руководителя, только потом "
                "закрывать увольнение и отзывать доступы."
            )
            check = (
                "Есть ли письменное подтверждение руководителя и активны ли ещё "
                "доступы у сотрудника."
            )
            start = (
                "Написать ответственному руководителю в официальном канале и "
                "запросить подтверждение; ответ сотрудника подтверждением не считать."
            )
        elif dstate in ("today", "overdue"):
            priority = "P2"
            action = "Закрыть увольнение, отозвать доступы, проверить финальный расчёт."
            start = "Проверить чек-лист увольнения и отозвать доступы."
        else:
            priority = "P3"
            action = "Держать карточку на контроле до подтверждения руководителя."
            start = "Запросить подтверждение заранее, не в последний день."

    elif case_type == "delivery":
        confirmation = crm.get("confirmation")
        status = (crm.get("status") or "").lower()
        if confirmation:
            at = parse_dt(confirmation.get("at"))
            who = confirmation.get("by") or "получатель"
            stamp = at.strftime("%H:%M") if at else "время не указано"
            confirmed.append(f"Приёмка, {who}, {stamp}")
            if claims.get("accepted_mentioned"):
                corroborated.append("получатель подтвердил получение в переписке")
            if claims.get("quantity_checked"):
                corroborated.append("количество сверено")
            priority = "P4"
            action = "Ничего не требуется: карточку можно закрыть."
            check = "Ничего, кроме закрытия карточки: приёмка уже зафиксирована."
            start = "Закрыть карточку, отдельного вмешательства не нужно."
        else:
            eta = claims.get("eta_not_before") or claims.get("eta")
            if eta:
                chat_only.append(
                    f"Курьер сообщил, что приедет не раньше {eta} (точное время не названо)"
                )
                conflicts.append(f"Статус в CRM («{crm.get('status', '—')}») не отражает задержку")
            if dstate in ("overdue", "today") and eta:
                priority = "P2"
                action = (
                    "Предупредить точку о задержке, запросить у курьера точное время "
                    "и обновить ожидаемое время в CRM."
                )
                check = (
                    "Предупреждена ли точка о задержке, назвал ли курьер точное время "
                    "(пока только «не раньше») и обновлён ли статус поставки в CRM."
                )
                start = (
                    "Сообщить на точку о задержке и уточнить у курьера точное время; "
                    "после этого согласовать приёмку и поправить ETA в CRM."
                )
            elif dstate == "overdue":
                priority = "P2"
                action = "Выяснить статус поставки и обновить данные в CRM."
                check = "Где находится поставка и когда реально приедет курьер."
                start = "Связаться с курьером и уточнить, где находится поставка."
            else:
                priority = "P3"
                action = "Проверить статус доставки ближе к сроку."
                start = "Дождаться обновления статуса и проконтролировать к сроку."
    else:
        missing.append("Тип кейса не распознан")
        priority = "P2"
        action = "Уточнить тип кейса и данные в CRM вручную."
        check = "Тип операции и полноту данных в CRM."
        start = "Открыть карточку и определить, что это за операция."

    return {
        "id": case.get("id", "—"),
        "type": TYPE_LABEL.get(case_type, case_type),
        "deadline": dlabel,
        "deadline_state": dstate,
        "sort_deadline": (deadline.replace(hour=23, minute=59) if deadline and deadline.hour == 0 and deadline.minute == 0 else deadline) or datetime.max,
        "confirmed": confirmed,
        "corroborated": corroborated,
        "chat_only": chat_only,
        "missing": missing,
        "conflicts": conflicts,
        "priority": priority,
        "action": action,
        "check": check,
        "start": start,
    }


def render(rows: list[dict], now: datetime, generated_at: datetime | None) -> str:
    rows = sorted(rows, key=lambda r: (PRIORITY_RANK[r["priority"]], r["sort_deadline"], r["id"]))
    stamp = generated_at or now

    lines = [
        f"# Сводка для support-отдела — {stamp:%d.%m.%Y, %H:%M}",
        "",
        "**Что подтверждено в CRM, что известно только из переписки.** "
        "Переписка — источник фактов, но не подтверждение: статус в CRM меняется "
        "только после действия в системе.",
        "",
        "## Порядок работы",
        "",
    ]
    for index, row in enumerate(
        (r for r in rows if r["priority"] in ("P1", "P2")), start=1
    ):
        lines.append(f"{index}. **{row['id']}** — {row['action']}")
    lines.append("")

    lines += [
        "## Сводная таблица",
        "",
        "| Кейс | Тип | Срок по CRM | Подтверждено в CRM | Только из переписки | Приоритет |",
        "|---|---|---|---|---|---|",
    ]
    for row in rows:
        confirmed = "; ".join(row["confirmed"]) or "—"
        chat_only = "; ".join(row["chat_only"]) or "—"
        lines.append(
            f"| {row['id']} | {row['type']} | {row['deadline']} | "
            f"{confirmed} | {chat_only} | {row['priority']} |"
        )
    lines.append("")

    lines += ["## Разбор по кейсам", ""]
    for row in rows:
        lines.append(f"### {row['id']} — {row['type']}. {PRIORITY_LABEL[row['priority']]}")
        lines.append("")
        lines.append(f"- Срок по CRM: {row['deadline']}.")
        if row["confirmed"]:
            lines.append(f"- Есть в CRM: {'; '.join(row['confirmed'])}.")
        if row["corroborated"]:
            lines.append(f"- Переписка совпадает с CRM: {'; '.join(row['corroborated'])}.")
        if row["chat_only"]:
            lines.append(f"- Только из переписки: {'; '.join(row['chat_only'])}.")
        if row["missing"]:
            lines.append(f"- Чего не хватает: {'; '.join(row['missing'])}.")
        if row["conflicts"]:
            lines.append(f"- Расхождение: {'; '.join(row['conflicts'])}.")
        lines.append(f"- Что проверить: {row['check']}")
        lines.append(f"- Что делать: {row['action']}")
        lines.append(f"- С чего начать: {row['start']}")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description="Rule layer of the support digest")
    parser.add_argument("input", type=Path, help="JSON produced by the LLM extractor")
    parser.add_argument("--now", help="Override current time, ISO format")
    parser.add_argument("--out", type=Path, help="Write Markdown to this file")
    args = parser.parse_args(argv)

    data = json.loads(args.input.read_text(encoding="utf-8"))
    now = parse_dt(args.now) or parse_dt(data.get("generated_at")) or datetime.now()
    generated_at = parse_dt(data.get("generated_at"))

    cases = data.get("cases") or []
    if not cases:
        print("Входной файл не содержит кейсов.", file=sys.stderr)
        return 2

    rows = [evaluate(case, now) for case in cases]
    digest = render(rows, now, generated_at)

    if args.out:
        args.out.write_text(digest, encoding="utf-8")
    print(digest)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
