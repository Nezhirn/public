"""Tests for the rule layer of the support digest."""

import unittest
from datetime import datetime

import support_digest as sd

NOW = datetime(2026, 10, 19, 10, 0)


def case(case_id="T-1", case_type="delivery", crm=None, claims=None):
    return {
        "id": case_id,
        "type": case_type,
        "crm": crm or {},
        "chat": {"claims": claims or {}, "quotes": []},
    }


class DeadlineTests(unittest.TestCase):
    def test_overdue(self):
        state, label = sd.deadline_state(datetime(2026, 10, 19, 9, 0), NOW)
        self.assertEqual(state, "overdue")
        self.assertIn("1 ч", label)

    def test_today_keeps_minutes(self):
        state, label = sd.deadline_state(datetime(2026, 10, 19, 18, 0), NOW)
        self.assertEqual(state, "today")
        self.assertEqual(label, "сегодня, 18:00")

    def test_midnight_has_no_clock(self):
        state, label = sd.deadline_state(datetime(2026, 10, 20), NOW)
        self.assertEqual(state, "tomorrow")
        self.assertEqual(label, "завтра")

    def test_date_only_today_is_not_overdue(self):
        state, label = sd.deadline_state(datetime(2026, 10, 19), NOW)
        self.assertEqual((state, label), ("today", "сегодня"))

    def test_date_only_yesterday_is_overdue(self):
        state, _ = sd.deadline_state(datetime(2026, 10, 18), NOW)
        self.assertEqual(state, "overdue")

    def test_missing_deadline(self):
        self.assertEqual(sd.deadline_state(None, NOW), ("unknown", "срок не указан"))


class OnboardingTests(unittest.TestCase):
    def test_docs_only_in_chat_is_critical(self):
        row = sd.evaluate(
            case("С-17", "onboarding",
                 {"deadline": "2026-10-20", "documents_received": False},
                 {"documents_sent": True, "channel": "руководителю в личку"}),
            NOW,
        )
        self.assertEqual(row["priority"], "P1")
        self.assertTrue(row["chat_only"])
        self.assertTrue(row["missing"])
        self.assertTrue(row["conflicts"])

    def test_docs_in_crm_is_planned(self):
        row = sd.evaluate(
            case("С-17", "onboarding",
                 {"deadline": "2026-10-20", "documents_received": True}),
            NOW,
        )
        self.assertEqual(row["priority"], "P3")
        self.assertFalse(row["missing"])


class OffboardingTests(unittest.TestCase):
    def test_missing_approval_blocks_offboarding(self):
        row = sd.evaluate(
            case("С-24", "offboarding",
                 {"deadline": "2026-10-19", "approval": None},
                 {"approval_mentioned": True}),
            NOW,
        )
        self.assertEqual(row["priority"], "P1")
        self.assertIn("со слов сотрудника", "; ".join(row["chat_only"]))
        self.assertTrue(row["conflicts"])

    def test_approval_in_crm_allows_closure(self):
        row = sd.evaluate(
            case("С-24", "offboarding",
                 {"deadline": "2026-10-19",
                  "approval": {"by": "Иванов", "at": "2026-10-19T09:00"}}),
            NOW,
        )
        self.assertEqual(row["priority"], "P2")
        self.assertFalse(row["missing"])


class DeliveryTests(unittest.TestCase):
    def test_delay_with_new_eta(self):
        row = sd.evaluate(
            case("П-08", "delivery",
                 {"deadline": "2026-10-19T10:00", "status": "В пути"},
                 {"eta_not_before": "13:00"}),
            NOW,
        )
        self.assertEqual(row["priority"], "P2")
        self.assertTrue(row["conflicts"])
        # courier said "not before 13:00": must not be presented as a firm ETA
        self.assertIn("не раньше 13:00", "; ".join(row["chat_only"]))

    def test_confirmed_delivery_is_closed(self):
        row = sd.evaluate(
            case("П-09", "delivery",
                 {"deadline": "2026-10-19T10:00", "status": "Принято",
                  "confirmation": {"by": "получатель", "at": "2026-10-19T09:20"}},
                 {"accepted_mentioned": True, "quantity_checked": True}),
            NOW,
        )
        self.assertEqual(row["priority"], "P4")
        self.assertTrue(row["corroborated"])
        self.assertFalse(row["chat_only"])

    def test_overdue_without_eta(self):
        row = sd.evaluate(
            case("П-10", "delivery",
                 {"deadline": "2026-10-19T08:00", "status": "В пути"}),
            NOW,
        )
        self.assertEqual(row["priority"], "P2")


class UnknownTypeTests(unittest.TestCase):
    def test_unknown_type_is_flagged_for_manual_review(self):
        row = sd.evaluate(case("X-1", "mystery"), NOW)
        self.assertEqual(row["priority"], "P2")
        self.assertIn("Тип кейса не распознан", row["missing"])


class RenderTests(unittest.TestCase):
    def test_critical_cases_go_first(self):
        rows = [
            sd.evaluate(case("A", "delivery",
                             {"deadline": "2026-10-19T10:00", "status": "Принято",
                              "confirmation": {"by": "x", "at": "2026-10-19T09:00"}}), NOW),
            sd.evaluate(case("B", "offboarding",
                             {"deadline": "2026-10-19", "approval": None}), NOW),
        ]
        text = sd.render(rows, NOW, NOW)
        self.assertLess(text.index("**B**"), text.index("## Сводная таблица"))


class OrderTests(unittest.TestCase):
    def test_same_priority_sorted_by_deadline(self):
        rows = [
            sd.evaluate(case("С-17", "onboarding",
                             {"deadline": "2026-10-20", "documents_received": False}), NOW),
            sd.evaluate(case("С-24", "offboarding",
                             {"deadline": "2026-10-19", "approval": None}), NOW),
        ]
        text = sd.render(rows, NOW, None)
        self.assertLess(text.index("### С-24"), text.index("### С-17"))


if __name__ == "__main__":
    unittest.main()
